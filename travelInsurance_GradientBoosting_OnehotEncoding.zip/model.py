import pandas as pd
import numpy as np
from sklearn.ensemble import BaggingClassifier, RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split as tts
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score, roc_auc_score, roc_curve
from flask import Flask, request, jsonify, render_template
import pickle
from sklearn.ensemble import GradientBoostingClassifier
#from imblearn.over_sampling import SMOTE




columns = ['ID','Agency','Agency Type', 'DistChannel', 'Product', 'Duration', 'Destination', 'NetSales', 'CommisionValue', 'Age','Claim']
df = pd.read_csv('data/train.csv',names=columns,skiprows=1)
#print(df['Duration'].describe())

from utils import processLabelEncode, processOneHotEncode

#df = processLabelEncode(df)


#df = processLabelEncode_Scaler(df)

#df = labelEncoded_df
# =============================================================================
# End of categorical
# =============================================================================
# removing duration outliear
df =  df.drop(["ID"],1)
df.drop(columns=['DistChannel','Agency Type'],axis=1,inplace=True)
df = processOneHotEncode(df)
#df.drop(df[df["Duration"]<=0].index, inplace = True)
df.loc[df['Duration'] <= 0.0, 'Duration'] = df['Duration'].mean()
df.loc[df['NetSales'] <= 0.0, 'CommisionValue'] = 0
#df.drop(df[df["Duration"]>=4000].index, inplace = True)
# end

#   low net sale but high comiision
#df6= df['NetSales']<df['CommisionValue']


X = df.drop(["Claim"],1)
y = df["Claim"]

X_train, X_test, y_train, y_test = tts(X,y,random_state = 42, test_size = 0.23)


# =============================================================================
# Random Forest
# =============================================================================
#model = pickle.load(open('ran_for.pkl', 'rb'))
##print (model.best_estimator_)
#model.fit(X_train,y_train) 
# 
#y_pred = model.predict(X_test)
#print(classification_report(y_test, y_pred))
#print (accuracy_score(y_test,y_pred))
# 
#test_df = pd.read_csv('data/test.csv')
#test_df =  test_df.drop(["ID"],1)
#df.loc[df['Duration'] <= 0.0, 'Duration'] = df['Duration'].mean()
#test_df.drop(columns=['Distribution Channel','Agency Type'],axis=1,inplace=True)
#test_df.loc[test_df['Net Sales'] <= 0.0, 'Commision (in value)'] = 0
#
#labelEncoded_test_df = processLabelEncode(test_df)
## =============================================================================
## Sample SUbmission
## =============================================================================
#sample_submission = pd.read_csv('data/sample_submission.csv')
#
## =============================================================================
## Prediction
## =============================================================================
#sample_submission.Claim = model.predict(labelEncoded_test_df)
#
#sample_submission.to_csv('results.csv')
# 
#=============================================================================


# =============================================================================
#Gadient boosting
lr_list = [0.05, 0.075, 0.1, 0.25, 0.5, 0.75, 1]
 
for learning_rate in lr_list:
    gb_clf = GradientBoostingClassifier(n_estimators=20, learning_rate=learning_rate, max_features=2, max_depth=2, random_state=0)
    gb_clf.fit(X_train, y_train)
 
    print("Learning rate: ", learning_rate)
    print("Accuracy score (training): {0:.3f}".format(gb_clf.score(X_train, y_train)))
    print("Accuracy score (validation): {0:.3f}".format(gb_clf.score(X_test, y_test)))
  
#=============================================================================

test_df = pd.read_csv('data/test.csv')
test_df =  test_df.drop(["ID"],1)
df.loc[df['Duration'] <= 0.0, 'Duration'] = df['Duration'].mean()
test_df.drop(columns=['Distribution Channel','Agency Type'],axis=1,inplace=True)
test_df.loc[test_df['Net Sales'] <= 0.0, 'Commision (in value)'] = 0

#labelEncoded_test_df = processLabelEncode(test_df)
labelEncoded_test_df = processOneHotEncode(test_df)

#labelEncoded_test_df = processLabelEncode_Scaler(test_df)


gb_clf2 = GradientBoostingClassifier(n_estimators=20, learning_rate=0.75, max_features=2, max_depth=2, random_state=0)
gb_clf2.fit(X_train, y_train)

sample_submission = pd.read_csv('data/sample_submission.csv')


sample_submission.Claim = gb_clf2.predict(labelEncoded_test_df)
sample_submission.to_csv('results.csv')
